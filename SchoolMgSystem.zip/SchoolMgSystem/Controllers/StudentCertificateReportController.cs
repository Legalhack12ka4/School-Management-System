﻿using DatabaseAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolMgSystem.Controllers
{
    public class StudentCertificateReportController : Controller
    {
        private CollageMgtSysDbEntities2 db = new CollageMgtSysDbEntities2();

        // GET: StudentCertificateReport
        public ActionResult LeavingC(int? id)
        {
            ViewBag.Message = "Ready to Print";

            var student = db.StudentPromateTables.Where(std => std.StudentID == id && std.IsActive == true).FirstOrDefault();
            if(student==null)
            {
                ViewBag.Message = "Already Printed";
                student = db.StudentPromateTables.Where(std => std.StudentID == id).OrderByDescending(e=>e.StudentPromateID).FirstOrDefault();
                return View(student);
            }

            return View(student);
        }
        [HttpPost]
        public ActionResult PrintLeavingC(int? id)
        {
     
            var student = db.StudentPromateTables.Where(std => std.StudentID == id && std.IsActive == true).FirstOrDefault();
           if(student == null)
            {
                ViewBag.Message = "Already Print! Please Contact To Admistration";
               student = db.StudentPromateTables.Where(std => std.StudentID == id).OrderByDescending(e => e.StudentPromateID).FirstOrDefault();

                return View("LeavingC", student);
            }
            student.IsActive = false;
            db.Entry(student).State=System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            ViewBag.Message = "Print Successfully";

            return View("LeavingC",student);
        }


        public ActionResult CharacterC(int? id)
        {

            ViewBag.Message = "Ready to Print";

            var student = db.StudentPromateTables.Where(std => std.StudentID == id && std.IsActive == true).FirstOrDefault();
            if (student == null)
            {
                ViewBag.Message = "Already Printed";
                student = db.StudentPromateTables.Where(std => std.StudentID == id).OrderByDescending(e => e.StudentPromateID).FirstOrDefault();
                return View(student);
            }

            return View(student);
        }
        public ActionResult ProvisionalC()
        {
            return View();
        }
     
    }
}