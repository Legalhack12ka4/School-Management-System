﻿using DatabaseAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolMgSystem.Controllers
{
    public class FeeReportsController : Controller
    {
        private CollageMgtSysDbEntities2 db = new CollageMgtSysDbEntities2();
        // GET: FeeReports

        public ActionResult CustomTutionFee()
        {
          
            var alltutionfee = db.SubmissionFeeTables.Where(e => e.SubmissionDate >= DateTime.Now && e.SubmissionDate <= DateTime.Now).ToList().OrderByDescending(e => e.SubmissionFeeID);
            return View(alltutionfee);
        }

        [HttpPost]
        public ActionResult CustomTutionFee(DateTime fromDate, DateTime toDate)
        {
            var alltutionfee = db.SubmissionFeeTables.Where(e => e.SubmissionDate >= fromDate && e.SubmissionDate <= toDate).ToList().OrderByDescending(e => e.SubmissionFeeID);
            return View(alltutionfee);
        }

        public ActionResult CustomAnnualFee()
        {

            var allannualfee = db.StudentPromateTables.Where(e => e.PromateDate >= DateTime.Now && e.PromateDate <= DateTime.Now && e.IsSubmit==true).ToList().OrderByDescending(e => e.StudentPromateID);
            return View(allannualfee);
        }

        [HttpPost]
        public ActionResult CustomAnnualFee(DateTime fromDate, DateTime toDate)
        {

            var allannualfee = db.StudentPromateTables.Where(e => e.PromateDate >= fromDate && e.PromateDate <= toDate && e.IsSubmit == true).ToList().OrderByDescending(e => e.StudentPromateID);
            return View(allannualfee);
        }
    }
}