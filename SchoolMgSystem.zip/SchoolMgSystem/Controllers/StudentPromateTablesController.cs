﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DatabaseAccess;

namespace SchoolMgSystem.Controllers
{
    public class StudentPromateTablesController : Controller
    {
        private CollageMgtSysDbEntities2 db = new CollageMgtSysDbEntities2();

        // GET: StudentPromateTables
        public ActionResult Index()
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");

            }
            var studentPromateTables = db.StudentPromateTables.Include(s => s.ClassTable).Include(s => s.ProgrameSessionTable).Include(s => s.StudentTable).Include(s => s.SectionTable).OrderByDescending(s => s.StudentPromateID);
            return View(studentPromateTables.ToList());
        }

        public ActionResult GetPromotClsList(string sid)
        {
            int studentid = Convert.ToInt32(sid);
            var student = db.StudentTables.Find(studentid);
            var promoteid = db.StudentPromateTables.Where(p => p.StudentID == studentid).Max(m=>m.StudentPromateID);
            List<ClassTable> classTable = new List<ClassTable>();
            if (promoteid > 0)
            {
                var promotetable = db.StudentPromateTables.Find(promoteid);
                foreach (var item in db.ClassTables.Where(cls => cls.ClassID >promotetable.ClassID))
                {

                    classTable.Add(new ClassTable { ClassID = item.ClassID, Name = item.Name });
                }
            }
            else
            {
                foreach (var cls in db.ClassTables.Where(cls => cls.ClassID > student.ClassID))
                {
                    classTable.Add(new ClassTable { ClassID = cls.ClassID, Name = cls.Name });
                }
            }
            return Json(new { data = classTable }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetAnnulFee(string sid)
        {
            
            int progsessid = Convert.ToInt32(sid);
            var ps = db.ProgrameSessionTables.Find(progsessid);
            var annualfee = db.AnnualTables.Where(a => a.AnnualID == ps.Programe_ID).SingleOrDefault();
        double? fee = annualfee.Fees;
            return Json(new { fees = fee }, JsonRequestBehavior.AllowGet);
        }

        // GET: StudentPromateTables/Details/5
        public ActionResult Details(int? id)
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");

            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentPromateTable studentPromateTable = db.StudentPromateTables.Find(id);
            if (studentPromateTable == null)
            {
                return HttpNotFound();
            }
            return View(studentPromateTable);
        }

        // GET: StudentPromateTables/Create
        public ActionResult Create()
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");

            }
            ViewBag.ClassID = new SelectList(db.ClassTables, "ClassID", "Name");
            ViewBag.ProgrameSessionID = new SelectList(db.ProgrameSessionTables, "ProgrameSessionID", "Details");
            ViewBag.StudentID = new SelectList(db.StudentTables, "StudentID", "Name");
            ViewBag.SectionID = new SelectList(db.SectionTables, "SectionID", "SectionName");
            return View();
        }

        // POST: StudentPromateTables/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(StudentPromateTable studentPromateTable)
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");

            }
            if (ModelState.IsValid)
            {
                db.StudentPromateTables.Add(studentPromateTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ClassID = new SelectList(db.ClassTables, "ClassID", "Name", studentPromateTable.ClassID);
            ViewBag.ProgrameSessionID = new SelectList(db.ProgrameSessionTables, "ProgrameSessionID", "Details", studentPromateTable.ProgrameSessionID);
            ViewBag.StudentID = new SelectList(db.StudentTables, "StudentID", "Name", studentPromateTable.StudentID);
            ViewBag.SectionID = new SelectList(db.SectionTables, "SectionID", "SectionName", studentPromateTable.SectionID);
            return View(studentPromateTable);
        }

        // GET: StudentPromateTables/Edit/5
        public ActionResult Edit(int? id)
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");

            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentPromateTable studentPromateTable = db.StudentPromateTables.Find(id);
            if (studentPromateTable == null)
            {
                return HttpNotFound();
            }
            ViewBag.ClassID = new SelectList(db.ClassTables, "ClassID", "Name", studentPromateTable.ClassID);
            ViewBag.ProgrameSessionID = new SelectList(db.ProgrameSessionTables, "ProgrameSessionID", "Details", studentPromateTable.ProgrameSessionID);
            ViewBag.StudentID = new SelectList(db.StudentTables, "StudentID", "Name", studentPromateTable.StudentID);
            ViewBag.SectionID = new SelectList(db.SectionTables, "SectionID", "SectionName", studentPromateTable.SectionID);
            return View(studentPromateTable);
        }

        // POST: StudentPromateTables/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(StudentPromateTable studentPromateTable)
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");

            }
        
            if (ModelState.IsValid)
            {
                db.Entry(studentPromateTable).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ClassID = new SelectList(db.ClassTables, "ClassID", "Name", studentPromateTable.ClassID);
            ViewBag.ProgrameSessionID = new SelectList(db.ProgrameSessionTables, "ProgrameSessionID", "Details", studentPromateTable.ProgrameSessionID);
            ViewBag.StudentID = new SelectList(db.StudentTables, "StudentID", "Name", studentPromateTable.StudentID);
            ViewBag.SectionID = new SelectList(db.SectionTables, "SectionID", "SectionName", studentPromateTable.SectionID);
            return View(studentPromateTable);
        }

        // GET: StudentPromateTables/Delete/5
        public ActionResult Delete(int? id)
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");

            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentPromateTable studentPromateTable = db.StudentPromateTables.Find(id);
            if (studentPromateTable == null)
            {
                return HttpNotFound();
            }
            return View(studentPromateTable);
        }

        // POST: StudentPromateTables/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");

            }
            StudentPromateTable studentPromateTable = db.StudentPromateTables.Find(id);
            db.StudentPromateTables.Remove(studentPromateTable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
