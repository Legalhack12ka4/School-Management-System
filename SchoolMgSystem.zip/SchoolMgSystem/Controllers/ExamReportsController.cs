﻿using DatabaseAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SchoolMgSystem.Controllers
{
    public class ExamReportsController : Controller
    {
        private CollageMgtSysDbEntities2 db = new CollageMgtSysDbEntities2();
        public ActionResult PrintDMC()
        {
            ViewBag.ExamID =new SelectList (db.ExamTables, "ExamID", "Title");
            return View(new List<ExamMarksTable>());
        }
      // GET: ExamReport
      [HttpPost()]
        public ActionResult PrintDMC(int? promoteid, int? examid)
        {
            float totalmarks = 0;
            ViewBag.ExamID = new SelectList(db.ExamTables, "ExamID", "Title");
            var promoterecord = db.StudentPromateTables.Find(promoteid);
            if(promoterecord != null)
            {
                var listmarks = db.ExamMarksTables.Where(e=>e.ClassSubjectTable.ClassID== promoterecord.ClassID && e.ExamID==examid && e.StudentID == promoterecord.StudentID);
              if(listmarks !=null)
                {

                }
                return View(listmarks);
            }
        
            return View(new List<ExamMarksTable>());
        }
    }
}